extends Node2D

const FONT_REGULAR: Font = preload("res://assets/fonts/ArabicUI-Regular.ttf")
const FONT_BOLD: Font = preload("res://assets/fonts/ArabicUI-Bold.ttf")
const SAVE_PATH := "user://arcadia_save.cfg"
const MAP_SIZE := 30
const TILE_W := 78.0
const TILE_H := 40.0
const TICK_SECONDS := 5.0

const COLORS := {
	"ink": Color("#182a2d"),
	"ink_soft": Color("#243a3b"),
	"panel": Color("#17282b"),
	"panel_light": Color("#263d3e"),
	"gold": Color("#e6bd6b"),
	"cream": Color("#f3e8cc"),
	"muted": Color("#9eb2a6"),
	"green": Color("#6e9a72"),
	"green_light": Color("#9ebd82"),
	"red": Color("#d17868"),
	"blue": Color("#6f9ba5"),
}

const BUILDING_DATA := {
	"hall": {"name": "تالار فرمانروایی", "desc": "مرکز اداره و پیشرفت شهر", "gold": 0, "wood": 0, "stone": 0, "food": 0, "rate": "مرکز", "color": Color("#d2b36e")},
	"farm": {"name": "مزرعه", "desc": "تولید پیوسته غذا برای ساکنان", "gold": 45, "wood": 30, "stone": 0, "food": 0, "rate": "+9 غذا", "color": Color("#9ebd73")},
	"lumber": {"name": "کارگاه چوب‌بری", "desc": "تأمین چوب برای ساخت‌وساز", "gold": 55, "wood": 0, "stone": 20, "food": 0, "rate": "+7 چوب", "color": Color("#c08d5c")},
	"quarry": {"name": "معدن سنگ", "desc": "استخراج سنگ از دل تپه‌ها", "gold": 65, "wood": 35, "stone": 0, "food": 0, "rate": "+6 سنگ", "color": Color("#9ea9a2")},
	"house": {"name": "خانه", "desc": "افزایش ظرفیت و رشد جمعیت", "gold": 35, "wood": 45, "stone": 0, "food": 0, "rate": "+8 ظرفیت", "color": Color("#c98564")},
	"market": {"name": "بازار", "desc": "رونق دادوستد و درآمد شهر", "gold": 0, "wood": 70, "stone": 35, "food": 0, "rate": "+5 طلا", "color": Color("#d8b36d")},
}

var resources := {"gold": 520, "food": 360, "wood": 420, "stone": 300}
var population := 24
var population_cap := 40
var happiness := 82
var city_level := 1
var day_count := 1
var tick_accumulator := 0.0
var autosave_accumulator := 0.0
var buildings: Array[Dictionary] = []
var selected_building_index := -1
var selected_tile := Vector2i(-1, -1)
var build_menu_open := false
var pending_build := ""
var toast_message := "به سرزمین آرکادیا خوش آمدی"
var toast_time := 4.0
var help_open := false
var charter_complete := false
var camera_offset := Vector2.ZERO
var camera_zoom := 0.92
var dragging := false
var drag_start := Vector2.ZERO
var drag_last := Vector2.ZERO
var drag_total := 0.0
var touch_points: Dictionary = {}
var pinch_distance := 0.0
var game_elapsed := 0.0

func _ready() -> void:
	_build_initial_city()
	_load_game()
	_recalculate_population_cap()
	camera_offset = get_viewport_rect().size * Vector2(0.50, 0.48) - iso_point(Vector2(14.5, 14.5)) * camera_zoom
	set_process(true)
	queue_redraw()

func _build_initial_city() -> void:
	buildings = [
		{"type": "hall", "x": 14, "y": 14, "level": 1},
		{"type": "farm", "x": 12, "y": 14, "level": 1},
		{"type": "lumber", "x": 16, "y": 13, "level": 1},
		{"type": "house", "x": 14, "y": 17, "level": 1},
	]

func _process(delta: float) -> void:
	game_elapsed += delta
	tick_accumulator += delta
	autosave_accumulator += delta
	if toast_time > 0.0:
		toast_time = maxf(0.0, toast_time - delta)
	if tick_accumulator >= TICK_SECONDS:
		tick_accumulator -= TICK_SECONDS
		_world_tick()
	if autosave_accumulator >= 35.0:
		autosave_accumulator = 0.0
		_save_game()
	queue_redraw()

func _world_tick() -> void:
	var rates := _production_rates()
	resources["food"] = maxi(0, int(resources["food"] + rates["food"] - ceil(float(population) * 0.22)))
	resources["wood"] += rates["wood"]
	resources["stone"] += rates["stone"]
	resources["gold"] += rates["gold"]
	if resources["food"] <= 0:
		happiness = maxi(10, happiness - 2)
	else:
		happiness = mini(100, happiness + 1)
	if resources["food"] > 100 and population < population_cap and happiness >= 55 and int(game_elapsed) % 25 < 5:
		population += 1
		toast_message = "جمعیت شهر یک نفر افزایش یافت"
		toast_time = 2.5
	if int(game_elapsed) % 90 < 5:
		day_count += 1
		toast_message = "روز تازه‌ای در آرکادیا آغاز شد"
		toast_time = 2.5
	city_level = 1 + int(maxi(0, buildings.size() - 4) / 3)

func _production_rates() -> Dictionary:
	var result := {"food": 0, "wood": 0, "stone": 0, "gold": 0}
	for building in buildings:
		var level := int(building.get("level", 1))
		match String(building.get("type", "")):
			"farm": result["food"] += 9 * level
			"lumber": result["wood"] += 7 * level
			"quarry": result["stone"] += 6 * level
			"market": result["gold"] += 5 * level
	return result

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var screen_event := event as InputEventScreenTouch
		if screen_event.pressed:
			touch_points[screen_event.index] = screen_event.position
			if touch_points.size() == 1:
				dragging = true
				drag_start = screen_event.position
				drag_last = screen_event.position
				drag_total = 0.0
			elif touch_points.size() == 2:
				var pts: Array = touch_points.values()
				var first_point: Vector2 = pts[0]
				var second_point: Vector2 = pts[1]
				pinch_distance = first_point.distance_to(second_point)
				dragging = false
				drag_total = 100.0
		else:
			touch_points.erase(screen_event.index)
			if touch_points.is_empty():
				if dragging and drag_total < 14.0:
					_handle_tap(screen_event.position)
				dragging = false
			elif touch_points.size() == 1:
				var remaining: Vector2 = touch_points.values()[0]
				dragging = true
				drag_last = remaining
				drag_total = 100.0
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		var screen_drag := event as InputEventScreenDrag
		if touch_points.has(screen_drag.index):
			touch_points[screen_drag.index] = screen_drag.position
			if touch_points.size() == 2:
				var pts: Array = touch_points.values()
				var first_point: Vector2 = pts[0]
				var second_point: Vector2 = pts[1]
				var new_distance := first_point.distance_to(second_point)
				if pinch_distance > 0.0:
					camera_zoom = clampf(camera_zoom * new_distance / pinch_distance, 0.60, 1.45)
				pinch_distance = new_distance
			elif dragging:
				camera_offset += screen_drag.relative
				drag_total += screen_drag.relative.length()
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		var mouse_event := event as InputEventMouseButton
		if mouse_event.button_index == MOUSE_BUTTON_LEFT:
			if mouse_event.pressed:
				dragging = true
				drag_start = mouse_event.position
				drag_last = mouse_event.position
				drag_total = 0.0
			else:
				if dragging and drag_total < 8.0:
					_handle_tap(mouse_event.position)
				dragging = false
		elif mouse_event.pressed and mouse_event.button_index == MOUSE_BUTTON_WHEEL_UP:
			camera_zoom = clampf(camera_zoom * 1.09, 0.60, 1.45)
		elif mouse_event.pressed and mouse_event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			camera_zoom = clampf(camera_zoom / 1.09, 0.60, 1.45)
	elif event is InputEventMouseMotion and dragging and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		camera_offset += (event as InputEventMouseMotion).relative
		drag_total += (event as InputEventMouseMotion).relative.length()

func _handle_tap(point: Vector2) -> void:
	var size := get_viewport_rect().size
	if help_open:
		help_open = false
		return
	if _hit(point, _help_button_rect(size)):
		help_open = true
		return
	if _hit(point, _save_button_rect(size)):
		_save_game()
		toast_message = "بازی ذخیره شد"
		toast_time = 2.0
		return
	if selected_building_index >= 0 and selected_building_index < buildings.size():
		var selected_panel := Rect2(size.x - 270, 138, 244, 205)
		if selected_panel.has_point(point):
			if _hit(point, _upgrade_button_rect(size)) and String(buildings[selected_building_index]["type"]) != "hall":
				_upgrade_selected()
			elif point.y > selected_panel.position.y + 150.0:
				selected_building_index = -1
			return
	if _hit(point, _build_button_rect(size)):
		build_menu_open = not build_menu_open
		pending_build = ""
		return
	if _hit(point, _city_button_rect(size)):
		build_menu_open = false
		selected_building_index = -1
		toast_message = "شهر تو در روز " + str(day_count) + " از دوران شکوفایی است"
		toast_time = 3.0
		return
	if _hit(point, _zoom_in_rect(size)):
		camera_zoom = minf(1.45, camera_zoom * 1.12)
		return
	if _hit(point, _zoom_out_rect(size)):
		camera_zoom = maxf(0.60, camera_zoom / 1.12)
		return
	if build_menu_open:
		var item_id := _build_item_at(point, size)
		if item_id != "":
			pending_build = item_id
			build_menu_open = false
			selected_building_index = -1
			toast_message = "جای مناسب را روی نقشه لمس کن"
			toast_time = 3.0
			return
	if point.y > size.y - 118.0:
		return
	var tile := _screen_to_tile(point)
	if tile.x < 0 or tile.y < 0 or tile.x >= MAP_SIZE or tile.y >= MAP_SIZE:
		return
	selected_tile = tile
	if pending_build != "":
		_try_build(tile)
		return
	selected_building_index = _building_at(tile)
	if selected_building_index < 0:
		toast_message = "این زمین خالی است؛ از بخش ساخت، بنایی انتخاب کن"
		toast_time = 2.5

func _build_item_at(point: Vector2, size: Vector2) -> String:
	var panel := _build_panel_rect(size)
	if not panel.has_point(point):
		return ""
	var ids := ["farm", "lumber", "quarry", "house", "market"]
	for i in range(ids.size()):
		var rect := Rect2(panel.position + Vector2(14, 70 + i * 68), Vector2(panel.size.x - 28, 58))
		if rect.has_point(point):
			return ids[i]
	return ""

func _try_build(tile: Vector2i) -> void:
	if _building_at(tile) >= 0:
		toast_message = "این قطعه زمین از قبل ساخته شده است"
		toast_time = 2.5
		return
	if _terrain_at(tile.x, tile.y) == 1:
		toast_message = "روی آب نمی‌توان ساختمان ساخت"
		toast_time = 2.5
		return
	var data: Dictionary = BUILDING_DATA[pending_build]
	for key in ["gold", "wood", "stone", "food"]:
		var cost := int(data.get(key, 0))
		if int(resources[key]) < cost:
			toast_message = "منابع کافی نیست؛ " + String(data["name"]) + " ساخته نشد"
			toast_time = 3.0
			return
	for key in ["gold", "wood", "stone", "food"]:
		resources[key] -= int(data.get(key, 0))
	buildings.append({"type": pending_build, "x": tile.x, "y": tile.y, "level": 1})
	_recalculate_population_cap()
	_check_charter()
	selected_building_index = buildings.size() - 1
	pending_build = ""
	_save_game()
	toast_message = String(data["name"]) + " با موفقیت ساخته شد"
	toast_time = 3.0

func _upgrade_selected() -> void:
	if selected_building_index < 0 or selected_building_index >= buildings.size():
		return
	var building: Dictionary = buildings[selected_building_index]
	if building["type"] == "hall":
		toast_message = "تالار فرمانروایی در این نسخه قابل ارتقا نیست"
		toast_time = 2.8
		return
	var level := int(building["level"])
	var gold_cost := 70 * level
	var wood_cost := 55 * level
	var stone_cost := 25 * level
	if resources["gold"] < gold_cost or resources["wood"] < wood_cost or resources["stone"] < stone_cost:
		toast_message = "برای ارتقا به طلا، چوب یا سنگ بیشتری نیاز داری"
		toast_time = 3.0
		return
	resources["gold"] -= gold_cost
	resources["wood"] -= wood_cost
	resources["stone"] -= stone_cost
	building["level"] = level + 1
	buildings[selected_building_index] = building
	_recalculate_population_cap()
	_save_game()
	toast_message = "سطح ساختمان به " + str(level + 1) + " ارتقا یافت"
	toast_time = 2.8

func _check_charter() -> void:
	var has_quarry := false
	var has_market := false
	for building in buildings:
		if String(building.get("type", "")) == "quarry": has_quarry = true
		if String(building.get("type", "")) == "market": has_market = true
	if has_quarry and has_market and not charter_complete:
		charter_complete = true
		resources["gold"] += 180
		resources["food"] += 150
		toast_message = "پیمان شکوفایی کامل شد؛ پاداش فرمانروا دریافت شد!"
		toast_time = 5.0
		_save_game()

func _recalculate_population_cap() -> void:
	population_cap = 32
	for building in buildings:
		if String(building.get("type", "")) == "house":
			population_cap += 8 * int(building.get("level", 1))
	population = mini(population, population_cap)

func _building_at(tile: Vector2i) -> int:
	for i in range(buildings.size()):
		if int(buildings[i]["x"]) == tile.x and int(buildings[i]["y"]) == tile.y:
			return i
	return -1

func _terrain_at(x: int, y: int) -> int:
	if x < 0 or y < 0 or x >= MAP_SIZE or y >= MAP_SIZE:
		return 1
	var edge := mini(mini(x, y), mini(MAP_SIZE - 1 - x, MAP_SIZE - 1 - y))
	var center_distance := Vector2(x - 14.0, y - 14.0).length()
	var noise := absf(sin(float(x) * 12.9898 + float(y) * 78.233) * 43758.5453)
	noise = fposmod(noise, 1.0)
	if edge == 0 and noise > 0.23:
		return 1
	if center_distance > 7.0 and noise > 0.73:
		return 2
	if center_distance > 8.0 and noise < 0.10:
		return 3
	return 0

func iso_point(tile: Vector2) -> Vector2:
	return Vector2((tile.x - tile.y) * TILE_W * 0.5, (tile.x + tile.y) * TILE_H * 0.5)

func _tile_center(tile: Vector2i) -> Vector2:
	return camera_offset + iso_point(Vector2(tile.x + 0.5, tile.y + 0.5)) * camera_zoom

func _screen_to_tile(point: Vector2) -> Vector2i:
	var p := (point - camera_offset) / camera_zoom
	var a := p.x / (TILE_W * 0.5)
	var b := p.y / (TILE_H * 0.5)
	return Vector2i(floori((a + b) * 0.5), floori((b - a) * 0.5))

func _save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("state", "resources", resources)
	cfg.set_value("state", "population", population)
	cfg.set_value("state", "population_cap", population_cap)
	cfg.set_value("state", "happiness", happiness)
	cfg.set_value("state", "day_count", day_count)
	cfg.set_value("state", "elapsed", game_elapsed)
	cfg.set_value("state", "charter_complete", charter_complete)
	cfg.set_value("state", "buildings", buildings)
	cfg.save(SAVE_PATH)

func _load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	resources = cfg.get_value("state", "resources", resources)
	population = int(cfg.get_value("state", "population", population))
	population_cap = int(cfg.get_value("state", "population_cap", population_cap))
	happiness = int(cfg.get_value("state", "happiness", happiness))
	day_count = int(cfg.get_value("state", "day_count", day_count))
	game_elapsed = float(cfg.get_value("state", "elapsed", game_elapsed))
	charter_complete = bool(cfg.get_value("state", "charter_complete", charter_complete))
	var saved_buildings = cfg.get_value("state", "buildings", buildings)
	if saved_buildings is Array and not saved_buildings.is_empty():
		buildings.assign(saved_buildings)
	_recalculate_population_cap()

func _draw() -> void:
	var size := get_viewport_rect().size
	_draw_backdrop(size)
	_draw_world(size)
	_draw_header(size)
	_draw_bottom_dock(size)
	_draw_status_card(size)
	if build_menu_open:
		_draw_build_menu(size)
	if selected_building_index >= 0 and selected_building_index < buildings.size():
		_draw_selected_panel(size)
	if pending_build != "":
		_draw_pending_hint(size)
	if help_open:
		_draw_help(size)
	if toast_time > 0.0:
		_draw_toast(size)

func _draw_backdrop(size: Vector2) -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("#172b2d"))
	for i in range(18):
		var y := float(i) * size.y / 18.0
		draw_line(Vector2(0, y), Vector2(size.x, y), Color(0.25, 0.39, 0.36, 0.07), 1.0)

func _draw_world(size: Vector2) -> void:
	var visible_tiles: Array[Vector2i] = []
	for y in range(MAP_SIZE):
		for x in range(MAP_SIZE):
			visible_tiles.append(Vector2i(x, y))
	visible_tiles.sort_custom(func(a: Vector2i, b: Vector2i) -> bool: return a.x + a.y < b.x + b.y)
	for tile in visible_tiles:
		var center := _tile_center(tile)
		if center.x < -100 or center.x > size.x + 100 or center.y < -100 or center.y > size.y + 120:
			continue
		_draw_tile(tile, center)
	var sorted_buildings := buildings.duplicate()
	sorted_buildings.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["x"]) + int(a["y"]) < int(b["x"]) + int(b["y"]))
	for building in sorted_buildings:
		var tile := Vector2i(int(building["x"]), int(building["y"]))
		var pos := _tile_center(tile)
		if pos.x > -100 and pos.x < size.x + 100 and pos.y > -100 and pos.y < size.y + 100:
			_draw_building(building, pos)
	if selected_building_index >= 0 and selected_building_index < buildings.size():
		var selected: Dictionary = buildings[selected_building_index]
		var selected_pos := _tile_center(Vector2i(int(selected["x"]), int(selected["y"])))
		_draw_diamond(selected_pos, TILE_W * camera_zoom * 0.52, TILE_H * camera_zoom * 0.54, Color(0.93, 0.75, 0.35, 0.18), 2.2)
	if selected_tile.x >= 0 and pending_build != "":
		_draw_diamond(_tile_center(selected_tile), TILE_W * camera_zoom * 0.5, TILE_H * camera_zoom * 0.5, Color(0.92, 0.78, 0.39, 0.40), 2.0)

func _draw_tile(tile: Vector2i, center: Vector2) -> void:
	var terrain := _terrain_at(tile.x, tile.y)
	var fill := Color("#6a8b62")
	match terrain:
		1: fill = Color("#4a7880")
		2: fill = Color("#557b58")
		3: fill = Color("#858e83")
		_: fill = Color("#76966b") if (tile.x + tile.y) % 2 == 0 else Color("#719064")
	_draw_diamond(center, TILE_W * camera_zoom * 0.5, TILE_H * camera_zoom * 0.5, fill, 0.8)
	if terrain == 1:
		draw_line(center + Vector2(-TILE_W * 0.22, 0), center + Vector2(TILE_W * 0.22, -2), Color(0.74, 0.87, 0.83, 0.22), 1.1 * camera_zoom)
	elif terrain == 2:
		_draw_tree(center + Vector2(-5, -7) * camera_zoom, 0.62 * camera_zoom)
	elif terrain == 3:
		draw_circle(center + Vector2(0, -4) * camera_zoom, 4.5 * camera_zoom, Color("#adb6a5"))

func _draw_diamond(center: Vector2, half_w: float, half_h: float, color: Color, outline_width: float) -> void:
	var pts := PackedVector2Array([center + Vector2(0, -half_h), center + Vector2(half_w, 0), center + Vector2(0, half_h), center + Vector2(-half_w, 0)])
	draw_colored_polygon(pts, color)
	var edge := color.darkened(0.24)
	draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), edge, outline_width)

func _draw_tree(pos: Vector2, scale: float) -> void:
	draw_circle(pos + Vector2(1, 5) * scale, 8.0 * scale, Color(0.12, 0.22, 0.17, 0.24))
	draw_rect(Rect2(pos + Vector2(-1.4, -2) * scale, Vector2(2.8, 11) * scale), Color("#735b3c"))
	draw_circle(pos + Vector2(0, -7) * scale, 8.3 * scale, Color("#315b43"))
	draw_circle(pos + Vector2(-4, -9) * scale, 5.4 * scale, Color("#47734e"))
	draw_circle(pos + Vector2(4, -5) * scale, 5.0 * scale, Color("#3d6948"))

func _draw_building(building: Dictionary, tile_center: Vector2) -> void:
	var t := String(building["type"])
	var level := int(building.get("level", 1))
	var s := camera_zoom
	var base := tile_center + Vector2(0, -3 * s)
	draw_circle(base + Vector2(0, 8 * s), 21 * s, Color(0.08, 0.14, 0.12, 0.22))
	var wall := Color("#d4c49c")
	var roof := Color("#9b6548")
	match t:
		"hall":
			wall = Color("#d7c89f")
			roof = Color("#8d654c")
			_draw_house_body(base, s, wall, roof, 1.32)
			_draw_tower(base + Vector2(-13, -15) * s, s, Color("#d7c89f"), Color("#9b744d"))
			_draw_tower(base + Vector2(13, -15) * s, s, Color("#d7c89f"), Color("#9b744d"))
			draw_line(base + Vector2(0, -42) * s, base + Vector2(0, -58) * s, Color("#593d2c"), 2.0 * s)
			draw_colored_polygon(PackedVector2Array([base + Vector2(0, -58) * s, base + Vector2(14, -54) * s, base + Vector2(0, -49) * s]), COLORS.gold)
		"farm":
			_draw_crop_rows(base + Vector2(-15, 7) * s, s)
			_draw_house_body(base + Vector2(0, -2) * s, s, Color("#d8c59b"), Color("#b06f49"), 0.85)
		"lumber":
			_draw_house_body(base + Vector2(0, -3) * s, s, Color("#c7af84"), Color("#79543c"), 0.9)
			for i in range(3):
				draw_line(base + Vector2(-20 + i * 5, 14) * s, base + Vector2(-8 + i * 5, 8) * s, Color("#9c7048"), 3 * s)
		"quarry":
			_draw_stone_stack(base + Vector2(-7, -1) * s, s)
			_draw_stone_stack(base + Vector2(8, 3) * s, s * 0.72)
		"house":
			_draw_house_body(base, s, Color("#e1d3ae"), Color("#b46d53"), 0.83)
		"market":
			_draw_house_body(base + Vector2(0, -2) * s, s, Color("#dbcba5"), Color("#bd8d50"), 1.0)
			for i in range(3):
				draw_circle(base + Vector2(-9 + i * 9, 7) * s, 2.5 * s, Color("#8b6842"))
	if level > 1:
		for i in range(mini(level - 1, 3)):
			draw_circle(base + Vector2(-7 + i * 7, -31) * s, 2.0 * s, COLORS.gold)

func _draw_house_body(pos: Vector2, s: float, wall: Color, roof: Color, factor: float) -> void:
	var w := 16.0 * factor * s
	var h := 15.0 * factor * s
	var front := PackedVector2Array([pos + Vector2(-w, -h * 0.25), pos + Vector2(0, h * 0.25), pos + Vector2(0, h + h * 0.25), pos + Vector2(-w, h * 0.65)])
	var side := PackedVector2Array([pos + Vector2(0, h * 0.25), pos + Vector2(w, -h * 0.25), pos + Vector2(w, h * 0.65), pos + Vector2(0, h + h * 0.25)])
	draw_colored_polygon(front, wall.lightened(0.05))
	draw_colored_polygon(side, wall.darkened(0.18))
	var roof_left := PackedVector2Array([pos + Vector2(-w - 3 * s, -h * 0.32), pos + Vector2(0, -h - 5 * s), pos + Vector2(0, -h * 0.1), pos + Vector2(-w - 3 * s, h * 0.20)])
	var roof_right := PackedVector2Array([pos + Vector2(0, -h - 5 * s), pos + Vector2(w + 3 * s, -h * 0.32), pos + Vector2(w + 3 * s, h * 0.20), pos + Vector2(0, -h * 0.1)])
	draw_colored_polygon(roof_left, roof.lightened(0.08))
	draw_colored_polygon(roof_right, roof.darkened(0.12))
	draw_rect(Rect2(pos + Vector2(-4 * s, 4 * s), Vector2(5 * s, 10 * s)), Color("#76543c"))
	draw_rect(Rect2(pos + Vector2(6 * s, 1 * s), Vector2(3.5 * s, 3.5 * s)), Color("#73949a"))

func _draw_tower(pos: Vector2, s: float, wall: Color, roof: Color) -> void:
	draw_rect(Rect2(pos + Vector2(-5, -2) * s, Vector2(10, 22) * s), wall)
	draw_colored_polygon(PackedVector2Array([pos + Vector2(-7, -2) * s, pos + Vector2(0, -15) * s, pos + Vector2(7, -2) * s]), roof)
	draw_rect(Rect2(pos + Vector2(-2, 7) * s, Vector2(4, 6) * s), Color("#6b4b37"))

func _draw_crop_rows(pos: Vector2, s: float) -> void:
	for i in range(3):
		draw_line(pos + Vector2(-4, i * 5) * s, pos + Vector2(20, i * 5 - 7) * s, Color("#d3b765"), 2.0 * s)
	for i in range(5):
		draw_line(pos + Vector2(i * 5, -2) * s, pos + Vector2(i * 5 - 5, 11) * s, Color("#426d44"), 1.5 * s)

func _draw_stone_stack(pos: Vector2, s: float) -> void:
	draw_colored_polygon(PackedVector2Array([pos + Vector2(-11, 6) * s, pos + Vector2(-4, -6) * s, pos + Vector2(6, -5) * s, pos + Vector2(12, 6) * s]), Color("#aab5aa"))
	draw_colored_polygon(PackedVector2Array([pos + Vector2(-4, -6) * s, pos + Vector2(3, -13) * s, pos + Vector2(11, -4) * s, pos + Vector2(6, -5) * s]), Color("#c6cbbd"))

func _draw_header(size: Vector2) -> void:
	_draw_panel(Rect2(20, 18, size.x - 40, 96), Color("#182b2c"), 19.0)
	draw_string(FONT_BOLD, Vector2(48, 57), "آرکادیا", HORIZONTAL_ALIGNMENT_LEFT, -1, 31, COLORS.gold)
	draw_string(FONT_REGULAR, Vector2(49, 83), "قلمرو سپیده‌دم  •  روز " + str(day_count), HORIZONTAL_ALIGNMENT_LEFT, -1, 15, COLORS.muted)
	var metrics := [
		{"key": "gold", "label": "طلا", "value": resources["gold"], "color": COLORS.gold, "icon": "◈"},
		{"key": "food", "label": "غذا", "value": resources["food"], "color": Color("#b7cd82"), "icon": "✦"},
		{"key": "wood", "label": "چوب", "value": resources["wood"], "color": Color("#c99a69"), "icon": "◆"},
		{"key": "stone", "label": "سنگ", "value": resources["stone"], "color": Color("#b7c4c1"), "icon": "⬟"},
	]
	var start_x := size.x - 660.0
	for i in range(metrics.size()):
		var x := start_x + i * 104.0
		_draw_resource_chip(Rect2(x, 34, 96, 60), metrics[i])
	_draw_mini_stat(Rect2(size.x - 220, 20, 184, 18), "جمعیت  " + str(population) + " / " + str(population_cap), COLORS.cream)
	_draw_mini_stat(Rect2(size.x - 220, 42, 184, 18), "رضایت  " + str(happiness) + "%", Color("#b5cb9a"))
	_draw_bar(Rect2(size.x - 220, 66, 184, 7), float(happiness) / 100.0, Color("#80a778"))
	_draw_button(_help_button_rect(size), "؟", false, Color("#41585a"), 18)

func _draw_resource_chip(rect: Rect2, item: Dictionary) -> void:
	_draw_panel(rect, Color("#263b3c"), 12.0)
	draw_circle(rect.position + Vector2(14, 18), 4.5, item["color"])
	draw_string(FONT_BOLD, rect.position + Vector2(25, 23), String(item["label"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, COLORS.cream)
	draw_string(FONT_BOLD, rect.position + Vector2(10, 48), _format_number(int(item["value"])), HORIZONTAL_ALIGNMENT_LEFT, -1, 18, item["color"])

func _draw_mini_stat(rect: Rect2, label: String, color: Color) -> void:
	draw_string(FONT_REGULAR, rect.position + Vector2(0, 14), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, color)

func _draw_bottom_dock(size: Vector2) -> void:
	var y := size.y - 96.0
	_draw_panel(Rect2(20, y, size.x - 40, 76), Color("#17292b"), 19.0)
	var w := 146.0
	var start := size.x * 0.5 - (w * 2.0 + 14.0)
	_draw_button(Rect2(start, y + 12, w, 52), "ساخت و ساز", build_menu_open, Color("#526e55"), 17)
	_draw_button(Rect2(start + w + 12, y + 12, w, 52), "شهر من", false, Color("#334a4a"), 17)
	_draw_button(Rect2(start + (w + 12) * 2, y + 12, w, 52), "ذخیره", false, Color("#334a4a"), 17)
	_draw_button(_zoom_out_rect(size), "−", false, Color("#334a4a"), 25)
	_draw_button(_zoom_in_rect(size), "+", false, Color("#334a4a"), 25)
	_draw_mini_stat(Rect2(48, y + 23, 190, 24), "سطح شهر  " + str(city_level) + "   |   " + str(buildings.size()) + " بنا", COLORS.muted)

func _draw_status_card(size: Vector2) -> void:
	var rates := _production_rates()
	var card := Rect2(26, 138, 232, 132)
	_draw_panel(card, Color(0.08, 0.15, 0.15, 0.88), 14.0)
	draw_string(FONT_BOLD, card.position + Vector2(15, 24), "گزارش شهر", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, COLORS.gold)
	draw_string(FONT_REGULAR, card.position + Vector2(15, 48), "غذا  +" + str(rates["food"]) + "    چوب  +" + str(rates["wood"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, COLORS.cream)
	draw_string(FONT_REGULAR, card.position + Vector2(15, 68), "سنگ  +" + str(rates["stone"]) + "    طلا  +" + str(rates["gold"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, COLORS.cream)
	draw_line(card.position + Vector2(14, 82), card.position + Vector2(card.size.x - 14, 82), Color(1, 1, 1, 0.12), 1)
	var mission := "پیمان شکوفایی: معدن و بازار بساز" if not charter_complete else "پیمان شکوفایی تکمیل شد"
	draw_string(FONT_BOLD, card.position + Vector2(15, 107), mission, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, COLORS.gold if charter_complete else COLORS.green_light)
	_draw_bar(Rect2(card.position + Vector2(15, 116), Vector2(card.size.x - 30, 5)), 1.0 if charter_complete else float(_charter_progress()) / 2.0, Color("#d1ae68"))

func _charter_progress() -> int:
	var count := 0
	for building in buildings:
		if String(building.get("type", "")) == "quarry" or String(building.get("type", "")) == "market":
			count += 1
	return mini(count, 2)

func _draw_build_menu(size: Vector2) -> void:
	var panel := _build_panel_rect(size)
	_draw_panel(panel, Color("#1b3031"), 18.0)
	draw_string(FONT_BOLD, panel.position + Vector2(20, 36), "ساخت ساختمان", HORIZONTAL_ALIGNMENT_LEFT, -1, 21, COLORS.gold)
	draw_string(FONT_REGULAR, panel.position + Vector2(20, 57), "یک بنا انتخاب کن، سپس زمین را لمس کن", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, COLORS.muted)
	var ids := ["farm", "lumber", "quarry", "house", "market"]
	for i in range(ids.size()):
		var id: String = ids[i]
		var data: Dictionary = BUILDING_DATA[id]
		var rect := Rect2(panel.position + Vector2(14, 70 + i * 68), Vector2(panel.size.x - 28, 58))
		_draw_panel(rect, Color("#2b4443"), 11.0)
		draw_circle(rect.position + Vector2(20, 29), 7, data["color"])
		draw_string(FONT_BOLD, rect.position + Vector2(38, 24), String(data["name"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 15, COLORS.cream)
		draw_string(FONT_REGULAR, rect.position + Vector2(38, 44), String(data["rate"]) + "   |   " + _cost_text(data), HORIZONTAL_ALIGNMENT_LEFT, -1, 11, COLORS.muted)

func _draw_selected_panel(size: Vector2) -> void:
	var panel := Rect2(size.x - 270, 138, 244, 205)
	_draw_panel(panel, Color("#1b3031"), 16.0)
	var building: Dictionary = buildings[selected_building_index]
	var type := String(building["type"])
	var data: Dictionary = BUILDING_DATA[type]
	draw_string(FONT_BOLD, panel.position + Vector2(17, 31), String(data["name"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 18, COLORS.gold)
	draw_string(FONT_REGULAR, panel.position + Vector2(17, 57), "سطح " + str(building["level"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, COLORS.cream)
	draw_string(FONT_REGULAR, panel.position + Vector2(17, 81), String(data["desc"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, COLORS.muted)
	draw_line(panel.position + Vector2(16, 96), panel.position + Vector2(panel.size.x - 16, 96), Color(1, 1, 1, 0.10), 1)
	if type != "hall":
		_draw_button(_upgrade_button_rect(size), "ارتقای ساختمان", false, Color("#806b3f"), 15)
	else:
		draw_string(FONT_REGULAR, panel.position + Vector2(17, 134), "تالار، قلب سرزمین توست", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, COLORS.muted)
	_draw_button(Rect2(panel.position.x + 16, panel.position.y + 159, panel.size.x - 32, 32), "بستن", false, Color("#334a4a"), 13)

func _draw_pending_hint(size: Vector2) -> void:
	_draw_panel(Rect2(size.x * 0.5 - 200, 132, 400, 42), Color("#59492e"), 12.0)
	var name: String = BUILDING_DATA[pending_build]["name"]
	draw_string(FONT_BOLD, Vector2(size.x * 0.5, 159), "مکان ساخت «" + name + "» را روی زمین انتخاب کن", HORIZONTAL_ALIGNMENT_CENTER, 380, 14, COLORS.cream)

func _draw_help(size: Vector2) -> void:
	_draw_panel(Rect2(size.x * 0.5 - 245, size.y * 0.5 - 170, 490, 340), Color("#1b3031"), 20)
	draw_string(FONT_BOLD, Vector2(size.x * 0.5, size.y * 0.5 - 120), "راهنمای فرمانروایی", HORIZONTAL_ALIGNMENT_CENTER, 430, 24, COLORS.gold)
	var lines := [
		"نقشه را با یک انگشت بکش و با دو انگشت بزرگ‌نمایی کن.",
		"از «ساخت و ساز» بنا انتخاب کن و یک قطعه زمین خالی را لمس کن.",
		"مزرعه غذا، کارگاه چوب‌بری چوب و معدن سنگ تولید می‌کند.",
		"خانه ظرفیت جمعیت را بالا می‌برد و بازار برای شهر طلا می‌سازد.",
		"روی ساختمان ساخته‌شده بزن تا اطلاعات و گزینه ارتقا را ببینی.",
		"بازی به‌صورت خودکار و روی همین گوشی ذخیره می‌شود؛ اینترنت لازم نیست.",
	]
	for i in range(lines.size()):
		draw_string(FONT_REGULAR, Vector2(size.x * 0.5, size.y * 0.5 - 72 + i * 32), lines[i], HORIZONTAL_ALIGNMENT_CENTER, 440, 13, COLORS.cream)
	_draw_button(Rect2(size.x * 0.5 - 70, size.y * 0.5 + 112, 140, 36), "متوجه شدم", false, Color("#526e55"), 14)

func _draw_toast(size: Vector2) -> void:
	var w := minf(500.0, size.x - 80.0)
	var rect := Rect2(size.x * 0.5 - w * 0.5, size.y - 151, w, 38)
	_draw_panel(rect, Color("#293e3b"), 12)
	draw_string(FONT_REGULAR, rect.position + Vector2(rect.size.x * 0.5, 25), toast_message, HORIZONTAL_ALIGNMENT_CENTER, rect.size.x - 20, 13, COLORS.cream)

func _draw_panel(rect: Rect2, color: Color, radius: float) -> void:
	draw_rect(rect.grow(2), Color(0, 0, 0, 0.12), true)
	draw_rect(rect, color, true)
	var edge := color.lightened(0.10)
	draw_line(rect.position + Vector2(radius * 0.6, 0), rect.position + Vector2(rect.size.x - radius * 0.6, 0), Color(edge.r, edge.g, edge.b, 0.32), 1)

func _draw_button(rect: Rect2, label: String, active: bool, color: Color, font_size: int) -> void:
	var fill := color.lightened(0.16) if active else color
	_draw_panel(rect, fill, 12)
	draw_string(FONT_BOLD, rect.position + Vector2(rect.size.x * 0.5, rect.size.y * 0.5 + font_size * 0.34), label, HORIZONTAL_ALIGNMENT_CENTER, rect.size.x - 12, font_size, COLORS.cream)

func _draw_bar(rect: Rect2, value: float, color: Color) -> void:
	draw_rect(rect, Color("#344a45"), true)
	draw_rect(Rect2(rect.position, Vector2(rect.size.x * clampf(value, 0.0, 1.0), rect.size.y)), color, true)

func _format_number(value: int) -> String:
	var text_value := str(value)
	var result := ""
	for i in range(text_value.length()):
		if i > 0 and (text_value.length() - i) % 3 == 0:
			result += ","
		result += text_value[i]
	return result

func _cost_text(data: Dictionary) -> String:
	var parts: Array[String] = []
	if int(data["gold"]) > 0: parts.append("طلا " + str(data["gold"]))
	if int(data["wood"]) > 0: parts.append("چوب " + str(data["wood"]))
	if int(data["stone"]) > 0: parts.append("سنگ " + str(data["stone"]))
	return PackedStringArray(parts).join("  •  ")

func _hit(point: Vector2, rect: Rect2) -> bool:
	return rect.has_point(point)

func _help_button_rect(size: Vector2) -> Rect2:
	return Rect2(278, 34, 36, 36)

func _save_button_rect(size: Vector2) -> Rect2:
	var w := 146.0
	var start := size.x * 0.5 - (w * 2.0 + 14.0)
	return Rect2(start + (w + 12) * 2, size.y - 84, w, 52)

func _build_button_rect(size: Vector2) -> Rect2:
	var w := 146.0
	var start := size.x * 0.5 - (w * 2.0 + 14.0)
	return Rect2(start, size.y - 84, w, 52)

func _city_button_rect(size: Vector2) -> Rect2:
	var w := 146.0
	var start := size.x * 0.5 - (w * 2.0 + 14.0)
	return Rect2(start + w + 12, size.y - 84, w, 52)

func _zoom_out_rect(size: Vector2) -> Rect2:
	return Rect2(size.x - 126, size.y - 84, 44, 52)

func _zoom_in_rect(size: Vector2) -> Rect2:
	return Rect2(size.x - 72, size.y - 84, 44, 52)

func _build_panel_rect(size: Vector2) -> Rect2:
	return Rect2(size.x - 310, 138, 284, 70 + 5 * 68 + 12)

func _upgrade_button_rect(size: Vector2) -> Rect2:
	var panel := Rect2(size.x - 270, 138, 244, 205)
	return Rect2(panel.position.x + 16, panel.position.y + 117, panel.size.x - 32, 32)
